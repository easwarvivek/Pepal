package sandmark;

public interface AppAlgorithm {}
