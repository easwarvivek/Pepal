package sandmark;

public interface ClassAlgorithm {}
