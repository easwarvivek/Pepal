package sandmark;

public interface MethodAlgorithm {}
