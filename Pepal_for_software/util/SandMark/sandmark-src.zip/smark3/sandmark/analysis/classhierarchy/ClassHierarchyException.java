package sandmark.analysis.classhierarchy;

public class ClassHierarchyException extends java.lang.Exception
{
        public ClassHierarchyException(String message)
        {
                super(message);
        }
}

