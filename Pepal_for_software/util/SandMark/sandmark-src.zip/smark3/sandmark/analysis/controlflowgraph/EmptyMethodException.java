package sandmark.analysis.controlflowgraph;

public class EmptyMethodException extends java.lang.RuntimeException {
   public EmptyMethodException() {
      super();
   }

   public EmptyMethodException(String msg) {
      super(msg);
   }
}
