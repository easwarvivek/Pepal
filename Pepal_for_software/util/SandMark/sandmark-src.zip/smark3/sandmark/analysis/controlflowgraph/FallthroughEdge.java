package sandmark.analysis.controlflowgraph;

public class FallthroughEdge extends sandmark.util.newgraph.EdgeImpl {
   public FallthroughEdge(java.lang.Object from, java.lang.Object to) {
      super(from, to);
   }
}
