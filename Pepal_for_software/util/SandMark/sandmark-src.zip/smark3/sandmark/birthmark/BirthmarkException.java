package sandmark.birthmark;

public class BirthmarkException extends Exception{
   public BirthmarkException(String message){
      super(message);
   }
}
