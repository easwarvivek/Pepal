package sandmark.birthmark;

public abstract class GeneralBirthmark extends sandmark.Algorithm{}
