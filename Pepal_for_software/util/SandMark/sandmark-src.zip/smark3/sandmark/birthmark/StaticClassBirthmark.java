package sandmark.birthmark;

public abstract class StaticClassBirthmark extends GeneralBirthmark{
   abstract public double calculate(StaticClassBirthMarkParameters params)
      throws Exception;
}
