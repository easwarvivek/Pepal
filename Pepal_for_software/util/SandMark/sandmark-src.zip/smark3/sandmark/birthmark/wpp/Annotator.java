package sandmark.birthmark.wpp;

public class Annotator {

   public static void MARK(){}

   public static void sm$mark(){
      MARK();
   }
}
