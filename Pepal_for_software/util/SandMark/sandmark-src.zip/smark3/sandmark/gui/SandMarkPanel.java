package sandmark.gui;

public interface SandMarkPanel {
    String getDescription();
    SandMarkFrame getFrame();
}
