package sandmark.obfuscate;

public class ObfuscationException extends java.lang.Exception
{
        public ObfuscationException(String message)
        {
                super(message);
        }
}

