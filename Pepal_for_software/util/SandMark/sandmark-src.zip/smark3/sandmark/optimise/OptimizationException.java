package sandmark.optimise;

public class OptimizationException extends java.lang.Exception
{
        public OptimizationException(String message)
        {
                super(message);
        }
}

