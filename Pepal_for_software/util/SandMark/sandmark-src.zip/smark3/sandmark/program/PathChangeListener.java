package sandmark.program;

public interface PathChangeListener {
    void pathChanged(java.io.File newPath);
}
